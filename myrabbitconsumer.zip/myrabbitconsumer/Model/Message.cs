﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myrabbitconsumer.Model
{
    public class Message
    {
        public string Greet { get; set; }
    }
}
